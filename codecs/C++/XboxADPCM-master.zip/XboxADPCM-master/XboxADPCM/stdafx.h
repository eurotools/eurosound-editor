#pragma once

#include <stdint.h>
#include <iostream>
#include <windows.h>
#include <string>