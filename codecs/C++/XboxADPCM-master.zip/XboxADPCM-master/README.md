Xbox ADPCM Converter
========
A tool for converting WAV files from Xbox ADPCM to PCM and vice versa.

ADPCM code by J.D.Medhurst (a.k.a. Tixy)

Requirements
--------
```
VS 2010 Redistributable
```

Usage
--------
```
XboxADPCM input_file [output_file]
```
It automaticly detects the converting mode.
For example, if input file is PCM format, the output file will be Xbox ADPCM format.

